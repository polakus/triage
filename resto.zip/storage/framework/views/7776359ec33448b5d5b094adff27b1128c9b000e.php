<?php 
 $salas= DB::table('salas as s')
                  ->join('Areas as a','a.id','=','s.id_area')
                  ->select('a.tipo_dato','s.nombre','s.camas','s.disponibilidad','s.id')
                  ->get();

?>

 <?php if($estado =="Internar"): ?>
                    <!-- Button trigger modal -->

                    <button type="button" class="btn btn-dark btn-sm" data-toggle="modal" data-target="#exampleModal<?php echo e($id); ?>" id="button1">

                      Asignar sala
                      
                    </button>


                  <!-- Modal -->
                  <div class="modal fade" id="exampleModal<?php echo e($id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h3 class="modal-title" id="exampleModalLabel">Salas</h3>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <div class="container col-md-12">

                                <?php $__currentLoopData = $salas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if($s->tipo_dato == "Internacion"): ?>
                                    <div class="row border">
                                      <div class="col border">
                                       <label><?php echo e($s->nombre); ?></label> 
                                      </div>

                                      <?php if($s->disponibilidad == 1): ?>
                                          <div class="col">
                                              <label>Disponible</label>
                                          </div>
                                          <div class="col border">
                                              
                                                
                                                
                                               
                                                <input type="hidden" name="sala" id="sala<?php echo e($s->id); ?>" value="<?php echo e($s->nombre); ?>">
                                                <input type="hidden" name="detalleatencion"  id="detalleatencion<?php echo e($id); ?>"value="<?php echo e($id); ?>">
                                                <input type="hidden" name="id_sala" id="id_sala<?php echo e($s->id); ?>" value=<?php echo e($s->id); ?>>
                                                <input type="hidden" name="tipo" id="tipo<?php echo e($id); ?>" value="Internado">
                                                <button type="button" onclick='cargarValores(<?php echo e($id); ?>,<?php echo e($s->id); ?>)' id="asignar"name="add" class="btn btn-success btn-sm asignar">Asignar esta sala</button>
                                              
                                          </div>
                                      <?php else: ?>
                                          <div class="col border">
                                            <label>No disponible</label>
                                          </div>
                                           <div class="col border">
                                            <button type="submit" id="add" name="add"  class="btn btn-success btn-sm" disabled>Asignar esta sala</button>
                                          </div>
                                      <?php endif; ?>
                                    </div>

                                  <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                          </div> 
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                        
                        </div>
                      </div>
                    </div>
                  </div>
                <?php else: ?>
                  <?php if($estado != "consulta" && $estado != "Operado"): ?>
                    <?php echo e($sala); ?>

                  <?php endif; ?>

  <?php endif; ?>

<?php /**PATH C:\xampp\htdocs\laravel\triage1\resources\views/turnos/actionsInternar.blade.php ENDPATH**/ ?>