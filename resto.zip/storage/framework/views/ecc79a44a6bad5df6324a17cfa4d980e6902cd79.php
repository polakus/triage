

<?php $__env->startSection("cuerpo"); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h4 class="h4">Analisis de acuerdo a los sintomas descriptos</h4>
</div>
<?php switch($casos):
	case ("disponibles"): ?>
	<div <?php if($color=="verde"): ?> class="alert alert-success" <?php elseif($color=="amarillo"): ?> class="alert alert-warning" <?php else: ?> class="alert alert-danger" <?php endif; ?>  role="alert">
		<h5 class="alert-heading">Resultados obtenidos</h5>
		<hr>
		<p>En estos momentos contamos con los siguientes especialistas disponibles para atender al paciente de acuerdo a los sintomas descriptos:</p>
		<ul>
		<?php $__currentLoopData = $msj_especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($msj); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		<hr>
		<p class="mb-0"><b>Si desea que el paciente sea atendido este dia, porfavor complete los siguientes datos:</b></p>
		<br>
		<form method="POST"  action="/turnos/cargaratencion">
		<?php echo csrf_field(); ?>
		<input type="hidden" name="atencion" value="<?php echo e($atencion); ?>">
		<input type="hidden" name="color" value="<?php echo e($color); ?>">
		<input type="hidden" name="casos" value="<?php echo e($casos); ?>">
			<div class="form-row">
					<div class="form-group col-md-4">
						<label>Elija que especialidad desea que lo atiendan:</label>
	  				<select class="form-control form-control-sm" name="esp">
	  					<?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $esp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <option value="<?php echo e($esp->id); ?>"><?php echo e($esp->nombre); ?></option>
						 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					</div>
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-dark btn-sm">Aceptar</button>
				<a href="<?php echo e(route('pacientes.index')); ?>" class="btn btn-dark btn-sm">Cancelar</a>
			</div>
		</form>
	</div>
	<?php break; ?>
	<?php case ("no disponibles"): ?>
	<div <?php if($color=="verde"): ?> class="alert alert-success" <?php elseif($color=="amarillo"): ?> class="alert alert-warning" <?php else: ?> class="alert alert-danger" <?php endif; ?>  role="alert">
		<h5 class="alert-heading">Resultados obtenidos</h5>
		<hr>
		<p>En estos momentos no se encuentran disponibles medicos para atender al paciente.</p>
		<p>Los especialistas capaces de atender al paciente son:</p>
		<ul>
		<?php $__currentLoopData = $nombres_especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($nombre); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		<hr>
		<p class="mb-0"><b>Si desea hacer esperar al paciente hasta que venga un medico, entonces complete los siguientes campos:</b></p>
		<br>
		<form method="POST"  action="/turnos/cargaratencion">
		<?php echo csrf_field(); ?>
		<input type="hidden" name="atencion" value="<?php echo e($atencion); ?>">
		<input type="hidden" name="color" value="<?php echo e($color); ?>">
		<input type="hidden" name="casos" value="<?php echo e($casos); ?>">
			<div class="form-row">
					<div class="form-group col-md-4">
						<label>Elija que especialidad desea que lo atiendan:</label>
	  				<select class="form-control form-control-sm" name="esp">
	  					<?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $esp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  <option value="<?php echo e($esp->id); ?>"><?php echo e($esp->nombre); ?></option>
						 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					</div>
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-dark btn-sm">Aceptar</button>
				<a href="<?php echo e(route('pacientes.index')); ?>" class="btn btn-dark btn-sm">Cancelar</a>
			</div>
		</form>
	</div>
	<?php break; ?>
	<?php case ("probabilidades"): ?>
	<div class="alert alert-secondary" role="alert">
		<h4 class="alert-heading">Coincidencias obtenidas!</h4>
		<hr>
		<p>Lo sentimos mucho, no se encontro algun protocolo pero si coincidencias con los que estan almacenados. </p>
		<ul>
		<?php $__currentLoopData = $msj_especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($msj); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		<hr>
		<p class="mb-0"><b>Si desea que el paciente sea atendido este dia, porfavor complete los siguientes datos:</b></p>
		<br>
		<form method="POST" action="/turnos/cargaratencion">
		<?php echo csrf_field(); ?>
		<input type="hidden" name="atencion" value="<?php echo e($atencion); ?>">
		<input type="hidden" name="casos" value="<?php echo e($casos); ?>">
		<input type="hidden" name="sintomas" value="<?php echo e(json_encode($sintomas,TRUE)); ?>">
			<div class="form-row">
					<div class="form-group col-md-2">
						<label>Especialidad</label>
	  				<select class="form-control form-control-sm" name="esp">
	  					<?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $esp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  <option value="<?php echo e($esp->id); ?>"><?php echo e($esp->nombre); ?></option>
					  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>

					</div>
					<div class="form-group col-md-2">
						<label>Codigo de triaje</label>
					<select class="form-control form-control-sm" name="color">
						<?php $__currentLoopData = $codigos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  <option value="<?php echo e($c->id); ?>"><?php echo e($c->color); ?></option>
					  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					</div>
					<div class="form-group col-md-4">
						<label>Desea guardar este nuevo protocolo?</label>
						<br>
						<div class="form-check form-check-inline">
						  <input class="form-check-input" type="radio" name="radios" id="radioSi" value="si">
						  <label class="form-check-label">
						   Si
						  </label>
						</div>
						<div class="form-check form-check-inline">
						  <input class="form-check-input" type="radio" name="radios" id="radioNo" value="no">
						  <label class="form-check-label">
						   No
						  </label>
						</div>
					</div>
			</div>
		
		<div class="form-group">
			<button type="submit" class="btn btn-dark btn-sm">Aceptar</button>
			<a href="<?php echo e(route('pacientes.index')); ?>" class="btn btn-dark btn-sm">Cancelar</a>
		</div>
	</form>
	</div>
	<?php break; ?>
	<?php case ("no protocolo"): ?>
		<div class="alert alert-secondary" role="alert">
		<h4 class="alert-heading">Resultado obtenido</h4>
		<hr>
		<p><b>Lo sentimos mucho, no se encontro algun protocolo o coincidencia con los sintomas que fueron descriptos.</b></p>
		<hr>
		<p class="mb-0"><b>Si desea que el paciente sea atendido, porfavor complete los siguientes datos:</b></p>
		<br>
		<form method="POST" action="/turnos/cargaratencion">
		<?php echo csrf_field(); ?>
		<input type="hidden" name="atencion" value="<?php echo e($atencion); ?>">
		<input type="hidden" name="casos" value="<?php echo e($casos); ?>">
		<input type="hidden" name="sintomas" value="<?php echo e(json_encode($sintomas,TRUE)); ?>">
			<div class="form-row">
					<div class="form-group col-md-2">
						<label>Especialidad</label>
	  				<select class="form-control form-control-sm" name="esp">
	  					<?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $esp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  <option value="<?php echo e($esp->id); ?>"><?php echo e($esp->nombre); ?></option>
					  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>

					</div>
					<div class="form-group col-md-2">
						<label>Codigo de triaje</label>
					<select class="form-control form-control-sm" name="color">
						<?php $__currentLoopData = $codigos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  <option value="<?php echo e($c->id); ?>"><?php echo e($c->color); ?></option>
					  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					</div>
					<div class="form-group col-md-4">
						<label>Desea guardar este nuevo protocolo?</label>
						<br>
						<div class="form-check form-check-inline">
						  <input class="form-check-input" type="radio" name="radios" id="radioSi" value="si">
						  <label class="form-check-label">
						   Si
						  </label>
						</div>
						<div class="form-check form-check-inline">
						  <input class="form-check-input" type="radio" name="radios" id="radioNo" value="no">
						  <label class="form-check-label">
						   No
						  </label>
						</div>
					</div>
			</div>
		
		<div class="form-group">
			<button type="submit" class="btn btn-dark btn-sm">Aceptar</button>
			<a href="<?php echo e(route('pacientes.index')); ?>" class="btn btn-dark btn-sm">Cancelar</a>
		</div>
	</form>
	</div>
	<?php break; ?>

<?php endswitch; ?>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('triagepreguntas.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\triage2\resources\views/turnos/respuesta.blade.php ENDPATH**/ ?>