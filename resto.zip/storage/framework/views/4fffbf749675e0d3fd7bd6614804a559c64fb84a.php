<div class="form-row">
 <form class= "form-inline" action="<?php echo e(route('triagepreguntas.show',$Paciente_id)); ?>" method="GET">
    <button type="submit" class="btn btn-sm btn-outline-secondary ml-1">Triaje</button>
  </form>
  <a href="/editar/<?php echo e($Paciente_id); ?>"  class="btn btn-sm btn-outline-secondary ml-1">Editar</a>
</div><?php /**PATH C:\xampp\htdocs\laravel\triage1\resources\views/pacientes/botones.blade.php ENDPATH**/ ?>