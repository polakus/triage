

<?php $__env->startSection("cabecera"); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection("cuerpo"); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h5 class="h5">Registracion de un nuevo protocolo</h5>
</div>
<div class="flash-message">
  <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(Session::has('alert-' . $msg)): ?>
      <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="<?php echo e(route('protocolos.index')); ?>" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<form method="POST" action="/protocolos/<?php echo e($protocolo->id); ?>">
  <?php echo csrf_field(); ?>
  <?php echo method_field('PUT'); ?>
  <div class="form-row">
    <div class="form-group col-md-4">
      <label for="inputEmail4">Descripción</label>
      <input type="text" name="desc"  class="form-control form-control-sm <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(count($errors) > 0 ? old('desc') : $protocolo->descripcion); ?>" placeholder="Nombre">
      <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <span class="invalid-feedback" role="alert">
          <strong><?php echo e($message); ?></strong>
      </span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group col-md-2">
      <label for="inputState">Código</label>
      <select name="codigo" id="inputState" class="form-control select">
        <?php $__currentLoopData = $codigos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $codigo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($codigo->color == $protocolo->color): ?>
            <option value="<?php echo e($codigo->id); ?>"selected><?php echo e($codigo->color); ?></option>
          <?php else: ?>
            <option value="<?php echo e($codigo->id); ?>"><?php echo e($codigo->color); ?></option>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="form-group col-md-2">
      <label for="inputEsp">Especialidad</label>
      <select name="especialidad" id="esp" class="form-control select">
        <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $esp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($esp->nombre == $protocolo->nombre): ?>
            <option value="<?php echo e($esp->id); ?>" selected=""><?php echo e($esp->nombre); ?></option>
          <?php else: ?>
             <option value="<?php echo e($esp->id); ?>"><?php echo e($esp->nombre); ?></option>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  </div>
   <h5>Sintomas Actuales</h5>
   <div class="table-responsive">
     <table id="tabla_actual" class="table table-sm table-bordered table-striped">
      <thead>
        <tr>
          <th>Descripcion</th>
        </tr>
       </thead>
       <tbody>
         <?php $__currentLoopData = $sintomas_actuales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sintoma_actual): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td> <?php echo e($sintoma_actual->descripcion); ?> </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <h5 >Sintomas para Agregar</h5>
    <?php $__errorArgs = ['cbs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <span style="color:#dc3545" role="alert">
          <strong><?php echo e($message); ?></strong>
      </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="table-responsive">
      <table id="dtBasicExample" class="table table-striped <?php $__errorArgs = ['cbs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> table-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> table-bordered table-sm" width="100%">
      <thead>
        <tr>
          <th>Acción      </th>
          <th>Descripción </th>
        </tr>
      </thead>
        <tbody>

        </tbody>
      </table>
    </div>
  <button type="submit" class="btn btn-mod">Editar</button>
  <a class="btn btn-outline-secondary btn-close" href="<?php echo e(route('protocolos.index')); ?>">Volver</a>
</form>
 
<?php $__env->stopSection(); ?>
<?php $__env->startSection("scripts"); ?>


<label></label>
<script type="text/javascript">
  $(document).ready(function() {
    $('#dtBasicExample').DataTable({
      "serverSide":true,
			"ajax":{
        url: "<?php echo e(url('api/editprotocolo')); ?>",
        data: {"id": <?php echo $protocolo->id;?>},
      },
			"columns":[ 
				{data:'checkbox'},
				{data:'descripcion'}, 
			],
      
       "language": {
        "decimal": ",",
        "thousands": ".",
        "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
        "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
        "infoPostFix": "",
        "infoFiltered": "(filtrado de un total de _MAX_ registros)",
        "loadingRecords": "Cargando...",
        "lengthMenu": "Mostrar _MENU_ registros",
        "paginate": {
            "first": "Primero",
            "last": "Último",
            "next": "Siguiente",
            "previous": "Anterior"
        },
        "processing": "Procesando...",
        "search": "Buscar:",
        "searchPlaceholder": "",
        "zeroRecords": "No se encontraron resultados",
        "emptyTable": "Ningún dato disponible en esta tabla",
        "aria": {
            "sortAscending":  ": Activar para ordenar la columna de manera ascendente",
            "sortDescending": ": Activar para ordenar la columna de manera descendente"
        },
        //only works for built-in buttons, not for custom buttons
        "buttons": {
            "create": "Nuevo",
            "edit": "Cambiar",
            "remove": "Borrar",
            "copy": "Copiar",
            "csv": "fichero CSV",
            "excel": "tabla Excel",
            "pdf": "documento PDF",
            "print": "Imprimir",
            "colvis": "Visibilidad columnas",
            "collection": "Colección",
            "upload": "Seleccione fichero...."
        },
        "select": {
            "rows": {
                _: '%d filas seleccionadas',
                0: 'clic fila para seleccionar',
                1: 'una fila seleccionada'
            }
        }
    }           
    });
} );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("triagepreguntas.test", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\triage2\resources\views/protocolos/edit.blade.php ENDPATH**/ ?>