

<?php $__env->startSection("cuerpo"); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
  <h4 class="h4">Sintomas</h4>
  <div class="ml-auto">
    <input type="text" class="form-control form-inline form-control-sm ml-2 " placeholder="Nombre del sintoma" style="width: 200px" name="nombre_sintoma" id="nombre_sintoma" >
    </div>
  <button class="btn btn-outline-secondary btn-sm ml-2"  id="agregar">Agregar sintoma</button>
 
  
</div>
<div class="table-responsive">
 <table class="table table-bordered table-striped table-hover table-sm" id="myTable">
  <thead>
    <tr>
      <th scope="col" >#</th>
      <th scope="col">Sintomas</th>
      <th scope="col" >Accion</th>
    </tr>
  </thead>
  <tbody>
 
  </tbody>
</table>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection("scripts"); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##








<script type="text/javascript">
  $(document).ready(function() {
   var table= $('#myTable').DataTable({
       "processing":true,
          "serverSide":true,
           "ajax":{url:"<?php echo e(url('api/sintomas_cargar')); ?>",
              
         },
           "columns":[
            {data:'id'},
            {data:'descripcion'},
            {data:'button'},
           ],
       "language": {
        "decimal": ",",
        "thousands": ".",
        "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
        "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
        "infoPostFix": "",
        "infoFiltered": "(filtrado de un total de _MAX_ registros)",
        "loadingRecords": "Cargando...",
        "lengthMenu": "Mostrar _MENU_ registros",
        "paginate": {
            "first": "Primero",
            "last": "Último",
            "next": "Siguiente",
            "previous": "Anterior"
        },
        "processing": "Procesando...",
        "search": "Buscar:",
        "searchPlaceholder": "",
        "zeroRecords": "No se encontraron resultados",
        "emptyTable": "Ningún dato disponible en esta tabla",
        "aria": {
            "sortAscending":  ": Activar para ordenar la columna de manera ascendente",
            "sortDescending": ": Activar para ordenar la columna de manera descendente"
        },
        //only works for built-in buttons, not for custom buttons
        "buttons": {
            "create": "Nuevo",
            "edit": "Cambiar",
            "remove": "Borrar",
            "copy": "Copiar",
            "csv": "fichero CSV",
            "excel": "tabla Excel",
            "pdf": "documento PDF",
            "print": "Imprimir",
            "colvis": "Visibilidad columnas",
            "collection": "Colección",
            "upload": "Seleccione fichero...."
        },
        "select": {
            "rows": {
                _: '%d filas seleccionadas',
                0: 'clic fila para seleccionar',
                1: 'una fila seleccionada'
            }
        }
    }           
    });

   $('#agregar').click(function() {
      var nombre_sintoma = $('#nombre_sintoma').val();
    
    $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
    });

   $.ajax({

            type:'POST',
            url:"/sintomas",
            dataType:"json",
            data:{
                nombre_sintoma:nombre_sintoma,
            },
            success: function(response){
                
                var table = $('#myTable').DataTable();
                table.draw();
                var inputNombre = document.getElementById("nombre_sintoma");
                inputNombre.value="";

                },
            error:function(err){
               if (err.status == 422) { // when status code is 422, it's a validation issue
            console.log(err.responseJSON);
            $('#success_message').fadeIn().html(err.responseJSON.message);
            $.each(err.responseJSON.errors, function (i, error) {
                // var el = $(document).find('[name="'+i+'"]');
                // el.after($('<span style="color: red;">'+error[0]+'</span>'));
                alert(error[0])
            });
        }
                // $("#labelNombre").text("Error 2");
                // $("#labelNombre").addClass('text-danger');
            }
        });
});
  
    
} );
</script>

<script type="text/javascript">
function eliminar(id){

  $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
    });
  $.ajax({

            type:'DELETE',
            url:"/sintomas/"+id,
            dataType:"json",
            data:{
                id:id,
            },
            success: function(response){
                var table=$("#myTable").DataTable();
                table.draw();

                },
            error:function(err){
        //        if (err.status == 422) { // when status code is 422, it's a validation issue
        //     console.log(err.responseJSON);
        //     $('#success_message').fadeIn().html(err.responseJSON.message);

            
        //     $.each(err.responseJSON.errors, function (i, error) {
                
        //         alert(error[0])
        //     });
        // }
               
            }
        });
}

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("triagepreguntas.test", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\triage1\resources\views/sintomas/index.blade.php ENDPATH**/ ?>