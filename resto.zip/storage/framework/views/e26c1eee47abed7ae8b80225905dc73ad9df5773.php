

<div class="form-row">
	<form id="f1" name="<?php echo e($usuario->username); ?>" class= "form-inline" method="GET" action="/usuarios/pendientes/<?php echo e($usuario->id); ?>/edit">
	<?php echo csrf_field(); ?>
		<button type="submit" class="btn btn-outline-secondary btn-sm ml-1 mb-1">Aceptar</button>
	</form>
	<form id="f2" name="<?php echo e($usuario->username); ?>" class= "form-inline" method="POST" action="/usuarios/pendientes/<?php echo e($usuario->id); ?>">
	<?php echo csrf_field(); ?>
		<?php echo e(method_field('DELETE')); ?>

		<button type="submit" class="btn btn-outline-secondary btn-sm ml-1 mb-1">Rechazar</button>
	</form>
</div><?php /**PATH C:\xampp\htdocs\laravel\triage2\resources\views/usuarios/buttons_pendientes.blade.php ENDPATH**/ ?>