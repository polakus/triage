


<?php $__env->startSection("cuerpo"); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h4 class="h4">Pacientes para atender</h4>
</div>
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token">

      <div id="Salas">
        <form method="POST" action="/atencionclinica/sala">
          <?php echo csrf_field(); ?>
        <h5>Indicar en que sala se encuentra situado</h5>
        <div class="form-row">
        
          <div class="form-group col-md-4" style="font-size: 17px;">
              <label for="inputState">Sala</label>
              <select name="sala" id="sala" class="form-control select">
                
                    <?php $__currentLoopData = $salas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <option value="<?php echo e($s->id); ?>-<?php echo e($s->tipo_dato); ?> <?php echo e($s->nombre); ?> "><?php echo e($s->tipo_dato); ?> <?php echo e($s->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>

      </div>
      <div class="row">
        <div class="col col-4">
          <button  type="submit" class="btn btn-outline-secondary btn-sm" style="width: 100%;">Listo</button>
        </div>
        
      </div>
      </form>
      </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make("triagepreguntas.test", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\triage2\resources\views/atencionclinica/index.blade.php ENDPATH**/ ?>