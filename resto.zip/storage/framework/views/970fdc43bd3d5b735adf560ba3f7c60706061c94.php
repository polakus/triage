
<?php if($estado!="alta"): ?>
<button  onclick="darAlta(<?php echo e($id); ?>)"class="btn btn-mod btn-sm" style="font-size: 13px;">Dar alta</button>

<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\triage2\resources\views/turnos/daralta.blade.php ENDPATH**/ ?>