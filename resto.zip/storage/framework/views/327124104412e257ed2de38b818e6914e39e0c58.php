
<?php if($estado!="alta"): ?>
<a href="<?php echo e(route('turnos.edit',$id)); ?>" class="btn btn-success btn-sm">Dar alta</a>

<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\triage\resources\views/turnos/daralta.blade.php ENDPATH**/ ?>