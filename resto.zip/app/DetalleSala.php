<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetalleSala extends Model
{
    //
     protected $table="Detalle_Salas";
}
