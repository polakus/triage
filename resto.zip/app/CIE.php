<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CIE extends Model
{
    //
    protected $table="cie";
}
