<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetalleProfSala extends Model
{
    //
    protected $table ="det_profesionales_salas";
}
